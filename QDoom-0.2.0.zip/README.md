# QDoom 0.2.0

A small, original corridor shooter for Q-SYS. The installable plugin is [QDoom.qplug](QDoom.qplug). It contains its own map, procedural wall textures, pixel-style monster art and weapon art. No external assets or audio are needed.

## Install and play

1. On a Windows machine with Q-SYS Designer, open `QDoom.qplug` or copy it to `Documents\QSC\Q-Sys Designer\Plugins`, then restart Designer.
2. Add **Fun → QDoom** to a design and start emulation. Open the component and press **Run**.
3. Keep **StepMode** on for touchscreen use: tap movement or turn controls, aim, and press **Fire** twice per monster. Turn StepMode off to hold controls for live movement and enemy AI. **Reset** restores health and enemies.

Copy `Screen`, `Info`, and any input pins to a UCI. Keep `Screen` at 16:9. The same controls are input pins for external wiring. `Run` and `StepMode` are toggles; the other buttons are momentary. The mini-map marks the player green and monsters red.

If replacing an older component, remove and re-add it; existing components can retain embedded plugin code.

## Rendering

The original grid DDA raycaster casts 64 rays into a 320 × 180 SVG. Wall tile type, hit side, and the hit position choose a small generated brick pattern. Monsters are original 10 × 12 pixel strips, scaled and clipped against wall depth per screen column. The gun has idle, recoil, and muzzle flash states. The single `Screen` button receives SVG as Base64 `IconData` in its Legend.

A 20 Hz timer handles input and gameplay, then assembles each requested image over nine callbacks: setup, four groups of 16 wall columns, sprites/HUD, SVG concatenation, Base64 encoding, and Legend assignment. At most one complete image appears about every 0.45 seconds. Changes made during assembly trigger another image. The renderer does not use QWolf3D art or source, and it does not port CCDoom or Pine3D.

## Local validation and remaining Q-SYS checks

`python3 test_qdoom.py` uses the temporary `lupa` Lua runtime installed at `/private/tmp/qdoom-test-deps`. The local harness checks plugin loading, controls, firing, collision stress, reset, 500 live ticks, pause, sprites, and repeated rendering. Its measured maximum was about 7,800 Lua VM instructions in one timer callback and about 20.6 KB of SVG in the final scene. Native Base64/Legend work is not represented by the VM count. Local measurements do not establish compliance with the Q-SYS execution budget.

Designer/Core was unavailable here. Validate the `.qplug` in Designer emulation and on the target Core: startup, step/live controls, holding buttons from a UCI and external pins, pause/reset, SVG display, and long play without `Max execution limits exceeded`. Record the Designer version and Debug Output if a problem occurs.

## Attribution and rights

QDoom source and generated art are original and covered by [LICENSE](LICENSE). QWolf3D by IntegratorBlocks was inspected for architecture only. The upload has no license or asset permission notice, and its embedded imagery and audio refer to Wolfenstein 3D/VSWAP content, so none was copied. See [PROJECT_NOTES.md](PROJECT_NOTES.md) for the detailed inspection and decisions.

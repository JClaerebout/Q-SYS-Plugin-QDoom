# QDoom project notes — 2026-10-01

## Starting point and preservation

The repository already contained `QDoom.qplug` 0.1.1, `README.md`, `test.lua`, `preview.svg`, and an MIT `LICENSE`, with uncommitted changes. QDoom 0.2.0 uses the original gameplay and DDA idea as the starting point. No commit, push, or publication was made. The older `test.lua` is retained as a historical harness; `test_qdoom.py` exercises the current staged renderer.

## Uploaded QWolf3D inspection

- `IB-QSYS-QWOLF3D-1.0.0.qplug` is a roughly 1.3 MB UTF-8 text plugin with embedded source modules and asset tables. It sets a Q-SYS button Legend to JSON containing `DrawChrome:false` and Base64 `IconData` for generated SVG.
- Wall data contains 34 used 64-column textures. Each column stores palette indices as hexadecimal strings; decoded columns are cached. The loader processes 16 wall columns per call, then one sprite per call. Sprite data uses 73 column/post tables with direct RGB hex colors, half vertical resolution, and transparent omitted pixels. Weapon frame tables store precomputed RGB pixel arrays from VSWAP. Rendering scales strips to projected screen size, clamps walls to visible vertical ranges, and depth-tests sprites by column.
- DDA raycasting is divided into two phases (left/right groups), retaining wall fragments and depth data between calls. Sprites and weapon render when the wall phase completes; a complete SVG is retained for display. The code has adaptive texture/sprite levels of detail, a preallocated 16-entry visible-sprite info pool, and horizontal run-length merging of matching wall rectangles. Final SVG concatenation and Base64 encoding are still done in a completion callback, so batching does not bound every part of the work.
- A master timer calls gameplay each tick, with HUD every sixth tick and debug information every thirtieth. Control EventHandlers set movement/action state. The game includes doors and enemy behavior.
- Audio is optional in code but uses a 7-channel BinLoop mapping and files under `Audio/WOLF3D/` on Core media storage. The upload includes a separate WOLF3D audio folder and a Q-SYS demo design; no audio is needed for QDoom.
- No LICENSE or NOTICE file was present in the uploaded directory and no clear reuse grant was found in the plugin header. Code permission is therefore unconfirmed. Embedded Wolfenstein 3D VSWAP images and audio are a separate rights question. QDoom copies none of that code or art and keeps the uploaded files untouched.

## CCDoom / Pine3D

The Xella37 repositories are ComputerCraft projects. CCDoom uses Pine3D and ComputerCraft terminal/image/event APIs, while QDoom must emit SVG through a Q-SYS Legend. Their renderer would require a large output adaptation with no clear execution-budget benefit for this small game. No port was added. See the repository pages: [CCDoom](https://github.com/Xella37/CCDoom) and [Pine3D](https://github.com/Xella37/Pine3D).

## Implementation and test record

- 64 DDA rays at 320 × 180; procedural brick bands and three palette families. Four timer calls cast 16 rays each. Subsequent callbacks draw sprites/HUD, concatenate XML, Base64 encode, and assign the Legend. Timer interval is 0.05 seconds, yielding about 2.2 complete frames/s if busy.
- Original compact pixel strips represent monsters. A fixed four-enemy map bounds sprite work; sprite strips are depth-tested and run-merged vertically. Weapon flash/recoil are timed states. Input controls remain wired Q-SYS pins.
- Initial local run failed the pause assertion because 500 live ticks could end in death; the harness now resets before asserting pause. No plugin runtime error was observed.
- `python3 test_qdoom.py` passed control loading, firing/kills, movement/collision stress, reset, 500 live ticks, pause, a close sprite, and repeated render cycles. Max callback sampled around 7,800 Lua VM instructions; P95 around 5,200. Final preview SVG was 20,586 bytes. The local test substitutes Base64 with a capture function, so native encoding and Legend transfer are unmeasured.
- Designer/Core was unavailable. Required next test: install in Designer, run the same actions over a sustained session, verify one-button SVG rendering and UCI/external pin behavior, and inspect Debug Output for execution-limit errors.
